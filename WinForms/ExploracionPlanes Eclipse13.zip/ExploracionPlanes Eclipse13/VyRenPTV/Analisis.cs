﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace ExploracionPlanes
{
    public class Analisis
    {
        public Structure estructura { get; set; }
        public IRestriccion restriccion { get; set; }

        
    }
}
